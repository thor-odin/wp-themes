</div>
<footer class="container-fluid text-center">
	<p>Footer Text</p>
</footer>
<!-- Footer End -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<?php wp_footer(); ?> 
  </body>
</html>